#!/bin/bash -ex

# Determine the full revision name.
GITDATE="`git show -s --date=short --format='%ad' | sed 's/-//g'`"
GITREV="`git show -s --format='%h'`"

# Archive and upload the artifacts.
mkdir -p artifacts

function pack_artifacts() {
    REV_NAME="azahar-$OS-$TARGET-$GITDATE-$GITREV"

    # Determine the name of the release being built.
    if [ "$GITHUB_REF_TYPE" = "tag" ]; then
        RELEASE_NAME=azahar-$GITHUB_REF_NAME
        REV_NAME="azahar-$OS-$TARGET-$GITHUB_REF_NAME"
    else
        RELEASE_NAME=azahar-head
    fi

    ARTIFACTS_PATH="$1"

    # Set up root directory for archive.
    mkdir "$REV_NAME"
    if [ -f "$ARTIFACTS_PATH" ]; then
        mv "$ARTIFACTS_PATH" "$REV_NAME"

        # Use file extension to differentiate archives.
        FILENAME=$(basename "$ARTIFACT")
        EXTENSION="${FILENAME##*.}"
        ARCHIVE_NAME="$REV_NAME.$EXTENSION"
    else
        mv "$ARTIFACTS_PATH"/* "$REV_NAME"

        ARCHIVE_NAME="$REV_NAME"
    fi

    # Create .zip/.tar.gz
    if [ "$OS" = "windows" ] && [ "$TARGET" != "mxe" ]; then
        ARCHIVE_FULL_NAME="$ARCHIVE_NAME.zip"
        powershell Compress-Archive "$REV_NAME" "$ARCHIVE_FULL_NAME"
    elif [ "$OS" = "android" ] || [ "$OS" = "macos" ] || [ "$TARGET" = "mxe" ]; then
        ARCHIVE_FULL_NAME="$ARCHIVE_NAME.zip"
        zip -r "$ARCHIVE_FULL_NAME" "$REV_NAME"
    else
        ARCHIVE_FULL_NAME="$ARCHIVE_NAME.tar.gz"
        tar czvf "$ARCHIVE_FULL_NAME" "$REV_NAME"
    fi
    mv "$ARCHIVE_FULL_NAME" artifacts/
     # Clean up created rev artifacts directory.
    rm -rf "$REV_NAME"
}

if [ -n "$UNPACKED" ]; then
    # Copy the artifacts to be uploaded unpacked.
    for ARTIFACT in build/bundle/*; do
        FILENAME=$(basename "$ARTIFACT")
        EXTENSION="${FILENAME##*.}"

        # TODO: Deduplicate
        REV_NAME="azahar-$OS-$TARGET-$GITDATE-$GITREV"

        # Determine the name of the release being built.
        if [ "$GITHUB_REF_TYPE" = "tag" ]; then
            RELEASE_NAME=azahar-$GITHUB_REF_NAME
            REV_NAME="azahar-$OS-$TARGET-$GITHUB_REF_NAME"
        else
            RELEASE_NAME=azahar-head
        fi

        mv "$ARTIFACT" "artifacts/$REV_NAME.$EXTENSION"
    done
elif [ -n "$PACK_INDIVIDUALLY" ]; then
    # Pack and upload the artifacts one-by-one.
    for ARTIFACT in build/bundle/*; do
        TARGET=$(basename "$ARTIFACT")
        pack_artifacts "$ARTIFACT"
    done
else
    # Pack all of the artifacts into a single archive.
    pack_artifacts build/bundle
fi
