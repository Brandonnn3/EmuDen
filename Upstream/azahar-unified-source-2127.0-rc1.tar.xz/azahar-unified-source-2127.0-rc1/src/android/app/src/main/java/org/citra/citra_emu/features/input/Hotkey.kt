// Copyright 2023-2026 Citra Emulator Project / Azahar Emulator Project
// Licensed under GPLv3 or any later version
// Refer to the LICENSE.txt file included.

package org.citra.citra_emu.features.input

enum class Hotkey(val button: Int) {
    SWAP_SCREEN(10001),
    CYCLE_LAYOUT(10002),
    CLOSE_GAME(10003),
    PAUSE_OR_RESUME(10004),
    QUICKSAVE(10005),
    QUICKLOAD(10006),
    TURBO_TOGGLE(10007),
    ENABLE(10008),
    TURBO_HOLD(10009),
    COMBO_BUTTON(10010)
}
