// Copyright 2023-2026 Citra Emulator Project / Azahar Emulator Project
// Licensed under GPLv3 or any later version
// Refer to the LICENSE.txt file included.

package org.citra.citra_emu.features.settings.ui.viewholder

import android.view.View
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.textview.MaterialTextView
import org.citra.citra_emu.R
import org.citra.citra_emu.features.settings.model.CitraSettings
import org.citra.citra_emu.features.settings.model.view.SettingsItem
import org.citra.citra_emu.features.settings.ui.SettingsAdapter

abstract class SettingViewHolder<out T : SettingsItem>(
    itemView: View,
    protected val adapter: SettingsAdapter
) : RecyclerView.ViewHolder(itemView),
    View.OnClickListener,
    View.OnLongClickListener {

    init {
        itemView.setOnClickListener(this)
        itemView.setOnLongClickListener(this)
    }

    /**
     * The SettingsItem we are holding
     */
    abstract val setting: T?

    /**
     * Called by the adapter to set this ViewHolder's child views to display the list item
     * it must now represent.
     *
     * @param item The list item that should be represented by this ViewHolder.
     */
    abstract fun bind(item: SettingsItem)

    /**
     * Called when this ViewHolder's view is clicked on. Implementations should usually pass
     * this event up to the adapter.
     *
     * @param clicked The view that was clicked on.
     */
    abstract override fun onClick(clicked: View)

    abstract override fun onLongClick(clicked: View): Boolean

    fun showGlobalMessageIfNeeded(globalMessage: MaterialTextView) {
        globalMessage.visibility = View.GONE
        setting ?: return
        setting?.setting ?: return

        val settings = adapter.fragmentView.activityView?.editingSettings
        val showGlobal = settings?.isPerApp() == true &&
            setting?.setting != null &&
            settings.hasOverride(setting!!.setting!!)

        if (showGlobal) {
            globalMessage.visibility = View.VISIBLE
            globalMessage.setText(R.string.use_global)
            return
        }
        val showMessage =
            settings?.isPerApp() == false && CitraSettings.activeSettings.isPerApp() &&
                CitraSettings.activeSettings.hasOverride(setting!!.setting!!)

        if (showMessage) {
            globalMessage.visibility = View.VISIBLE
            globalMessage.setText(R.string.editing_global_when_customized)
        }
    }
}
