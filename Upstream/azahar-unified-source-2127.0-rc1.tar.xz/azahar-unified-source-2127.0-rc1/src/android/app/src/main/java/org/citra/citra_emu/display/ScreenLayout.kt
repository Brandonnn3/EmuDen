// Copyright 2023-2026 Citra Emulator Project / Azahar Emulator Project
// Licensed under GPLv2 or any later version
// Refer to the misc/licenses/gplv2.txt file included.

package org.citra.citra_emu.display

enum class ScreenLayout(val int: Int) {
    // These must match what is defined in src/common/settings.h
    ORIGINAL(0),
    SINGLE_SCREEN(1),
    LARGE_SCREEN(2),
    SIDE_SCREEN(3),
    HYBRID_SCREEN(4),
    CUSTOM_LAYOUT(5);

    companion object {
        fun from(int: Int): ScreenLayout = entries.firstOrNull { it.int == int } ?: LARGE_SCREEN
    }
}

enum class SmallScreenPosition(val int: Int) {
    TOP_RIGHT(0),
    MIDDLE_RIGHT(1),
    BOTTOM_RIGHT(2),
    TOP_LEFT(3),
    MIDDLE_LEFT(4),
    BOTTOM_LEFT(5),
    ABOVE(6),
    BELOW(7);

    companion object {
        fun from(int: Int): SmallScreenPosition = entries.firstOrNull { it.int == int } ?: TOP_RIGHT
    }
}

enum class PortraitScreenLayout(val int: Int) {
    // These must match what is defined in src/common/settings.h
    TOP_FULL_WIDTH(0),
    CUSTOM_PORTRAIT_LAYOUT(1),
    ORIGINAL(2);

    companion object {
        fun from(int: Int): PortraitScreenLayout =
            entries.firstOrNull { it.int == int } ?: TOP_FULL_WIDTH
    }
}

enum class SecondaryDisplayLayout(val int: Int) {
    // These must match what is defined in src/common/settings.h
    // NONE is no longer selectable in the interface, having been replaced with
    // the boolean ENABLE_SECONDARY_DISPLAY setting, but is left here for backwards compatibility
    NONE(0),
    TOP_SCREEN(1),
    BOTTOM_SCREEN(2),
    SIDE_BY_SIDE(3),
    REVERSE_PRIMARY(4),
    ORIGINAL(5),
    HYBRID(6),
    LARGE_SCREEN(7)
    ;

    companion object {
        fun from(int: Int): SecondaryDisplayLayout = entries.firstOrNull { it.int == int } ?: NONE
    }
}

enum class StereoWhichDisplay(val int: Int) {
    // These must match what is defined in src/common/settings.h

    NONE(0), // equivalent to StereoRenderOption = Off
    BOTH(1),
    PRIMARY_ONLY(2),
    SECONDARY_ONLY(3);

    companion object {
        fun from(int: Int): StereoWhichDisplay = entries.firstOrNull { it.int == int } ?: NONE
    }
}

enum class StereoMode(val int: Int) {
    // These must match what is defined in src/common/settings.h

    OFF(0),
    SIDE_BY_SIDE(1),
    SIDE_BY_SIDE_FULL(2),
    ANAGLYPH(3),
    INTERLACED(4),
    REVERSE_INTERLACED(5),
    CARDBOARD_VR(6);

    companion object {
        fun from(int: Int): StereoMode = entries.firstOrNull { it.int == int } ?: OFF
    }
}
