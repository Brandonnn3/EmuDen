// Copyright 2023-2026 Citra Emulator Project / Azahar Emulator Project
// Licensed under GPLv3 or any later version
// Refer to the LICENSE.txt file included.

package org.citra.citra_emu.features.settings.ui

import android.net.Uri
import android.os.Bundle
import androidx.documentfile.provider.DocumentFile
import org.citra.citra_emu.CitraApplication
import org.citra.citra_emu.NativeLibrary
import org.citra.citra_emu.features.settings.model.BooleanSetting
import org.citra.citra_emu.features.settings.model.CitraSettings
import org.citra.citra_emu.features.settings.model.SettingsViewModel
import org.citra.citra_emu.features.settings.utils.SettingsFile
import org.citra.citra_emu.utils.DirectoryInitialization
import org.citra.citra_emu.utils.FileUtil
import org.citra.citra_emu.utils.Log
import org.citra.citra_emu.utils.PermissionsHandler
import org.citra.citra_emu.utils.SystemSaveGame
import org.citra.citra_emu.utils.TurboHelper

class SettingsActivityPresenter(
    private val activityView: SettingsActivityView,
    private val viewModel: SettingsViewModel
) {
    val editingSettings: CitraSettings get() = viewModel.editingSettings

    private var shouldSave = false
    private lateinit var menuTag: String
    private lateinit var gameId: String
    private lateinit var gameTitle: String

    fun onCreate(savedInstanceState: Bundle?, menuTag: String, gameId: String, gameTitle: String) {
        this.menuTag = menuTag
        this.gameId = gameId
        this.gameTitle = gameTitle

        if (savedInstanceState != null) {
            shouldSave = savedInstanceState.getBoolean(KEY_SHOULD_SAVE)
        } else {
            // sync the active settings into my local settings appropriately
            // if we are editing global settings rom a game, this should just work
            // to sync only the global settings into the local version
            editingSettings.gameId = if (gameId != "") gameId else null
            editingSettings.mergeSettings(CitraSettings.activeSettings)

            // if we are editing per-game settings when the game is not loaded,
            // we need to load the per-game settings now from the ini file
            if (gameId != "" && CitraSettings.activeSettings.gameId != gameId) {
                SettingsFile.loadCustomSettings(editingSettings, gameId)
            }
        }
    }

    fun onResume() {
        SystemSaveGame.load()
    }

    fun onPause() {
        SystemSaveGame.save()
    }

    fun onStart() {
        prepareDirectoriesIfNeeded()
    }

    private fun loadSettingsUI() {
        activityView.showSettingsFragment(menuTag, false, gameId, gameTitle)
        activityView.onSettingsFileLoaded()
    }

    private fun prepareDirectoriesIfNeeded() {
        if (!DirectoryInitialization.areCitraDirectoriesReady()) {
            DirectoryInitialization.start()
        }
        loadSettingsUI()
    }

    private fun updateAndroidImageVisibility() {
        val dataDirTreeUri: Uri
        val dataDirDocument: DocumentFile
        val nomediaFileDocument: DocumentFile?
        val nomediaFileExists: Boolean
        try {
            dataDirTreeUri = PermissionsHandler.citraDirectory
            dataDirDocument =
                DocumentFile.fromTreeUri(CitraApplication.appContext, dataDirTreeUri)!!
            nomediaFileDocument = dataDirDocument.findFile(".nomedia")
            nomediaFileExists = (nomediaFileDocument != null)
        } catch (e: Exception) {
            Log.error(
                "[SettingsActivity]: Error occurred while trying to find .nomedia, error: " +
                    e.message
            )
            return
        }

        if (editingSettings.get(BooleanSetting.ANDROID_HIDE_IMAGES)) {
            if (!nomediaFileExists) {
                Log.info("[SettingsActivity]: Attempting to create .nomedia in user data directory")
                FileUtil.createFile(dataDirTreeUri.toString(), ".nomedia")
            }
        } else if (nomediaFileExists) {
            Log.info("[SettingsActivity]: Attempting to delete .nomedia in user data directory")
            nomediaFileDocument!!.delete()
        }
    }

    fun onStop(finishing: Boolean) {
        if (finishing && shouldSave) {
            Log.debug("[SettingsActivity] Settings activity stopping. Saving settings to INI...")
            if (editingSettings.isPerApp()) {
                SettingsFile.saveCustomFile(editingSettings, activityView)
            } else {
                SettingsFile.saveGlobalFile(editingSettings, activityView)
            }
            // merge the edited settings back into the active settings
            CitraSettings.activeSettings.mergeSettings(editingSettings)
            NativeLibrary.reloadSettings()
            applyChangedSettings()
        }
    }

    fun onSettingChanged() {
        shouldSave = true
    }

    fun onSettingsReset() {
        shouldSave = false
    }

    fun applyChangedSettings() {
        NativeLibrary.updateFramebuffer(NativeLibrary.isPortraitMode())
        updateAndroidImageVisibility()
        TurboHelper.reloadTurbo(false) // TODO: Can this go somewhere else? -OS
    }

    fun saveState(outState: Bundle) {
        outState.putBoolean(KEY_SHOULD_SAVE, shouldSave)
    }

    companion object {
        private const val KEY_SHOULD_SAVE = "should_save"
    }
}
