// Copyright 2025 Citra Emulator Project / Azahar Emulator Project
// Licensed under GPLv2 or any later version
// Refer to the misc/licenses/gplv2.txt file included.

namespace QtSwizzle {

void Dummy();

} // namespace QtSwizzle
