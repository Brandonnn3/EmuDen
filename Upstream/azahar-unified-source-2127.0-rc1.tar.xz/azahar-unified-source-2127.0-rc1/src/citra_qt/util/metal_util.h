// Copyright 2026 Citra Emulator Project / Azahar Emulator Project
// Licensed under GPLv2 or any later version
// Refer to the misc/licenses/gplv2.txt file included.

#import "qwindowdefs.h"

namespace MetalUtil {

void* CreateMetalLayer(WId window);

}
