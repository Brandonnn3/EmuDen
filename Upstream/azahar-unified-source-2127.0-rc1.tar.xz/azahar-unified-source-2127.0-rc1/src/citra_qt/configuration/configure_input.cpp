// Copyright 2017-2026 Citra Emulator Project / Azahar Emulator Project
// Licensed under GPLv3 or any later version
// Refer to the LICENSE.txt file included.

#include <algorithm>
#include <memory>
#include <utility>
#include <QInputDialog>
#include <QKeyEvent>
#include <QLabel>
#include <QMenu>
#include <QMessageBox>
#include <QSlider>
#include <QTimer>
#include "citra_qt/configuration/config.h"
#include "citra_qt/configuration/configure_input.h"
#include "citra_qt/configuration/configure_motion_touch.h"
#include "citra_qt/uisettings.h"
#include "common/param_package.h"
#include "core/core.h"
#include "ui_configure_input.h"

enum class AnalogSubButtons {
    up,
    down,
    left,
    right,
    up_left,
    up_right,
    down_left,
    down_right,
    modifier,
};

static QString GetKeyName(int key_code) {
    switch (key_code) {
    case Qt::Key_Shift:
        return QObject::tr("Shift");
    case Qt::Key_Control:
        return QObject::tr("Ctrl");
    case Qt::Key_Alt:
        return QObject::tr("Alt");
    case Qt::Key_Meta:
        return QString{};
    default:
        return QKeySequence(key_code).toString();
    }
}

static QString ButtonToText(const Common::ParamPackage& param) {
    if (param.Get("engine", "") == "keyboard") {
        return GetKeyName(param.Get("code", 0));
    } else {
        return QString::fromStdString(InputCommon::ButtonToText(param));
    }
}

static QString AnalogToText(const Common::ParamPackage& param, const std::string& dir) {
    // If this is an analog stick made from buttons, keyboards will need to be handled
    // here at the frontend rather than at InputCommon
    // It might be nice to move the GetKeyName code to input_common, but would need a non-QT way of
    // doing it
    if (param.Get("engine", "") == "analog_from_button") {
        auto dir_param = Common::ParamPackage(param.Get(dir, ""));
        if (dir_param.Get("engine", "") == "keyboard") {
            return GetKeyName(dir_param.Get("code", 0));
        }
    }
    return QString::fromStdString(InputCommon::AnalogToText(param, dir));
}

ConfigureInput::ConfigureInput(Core::System& _system, QWidget* parent)
    : QWidget(parent), system(_system), ui(std::make_unique<Ui::ConfigureInput>()),
      timeout_timer(std::make_unique<QTimer>()), poll_timer(std::make_unique<QTimer>()) {
    ui->setupUi(this);
    setFocusPolicy(Qt::ClickFocus);

    for (const auto& profile : Settings::values.input_profiles) {
        ui->profile->addItem(QString::fromStdString(profile.name));
    }

    ui->profile->setCurrentIndex(Settings::values.current_input_profile_index);

    // clang-format off
    analog_sub_buttons = {
        "up",       "down",      "left",       "right",    "up_left",
        "up_right", "down_left", "down_right", "modifier",
    };

    analog_sub_button_names = {
        tr("Up"),       tr("Down"),      tr("Left"),       tr("Right"),    tr("Up-Left"),
        tr("Up-Right"), tr("Down-Left"), tr("Down-Right"), tr("Modifier"),
    };

    button_map = {
        ui->buttonA,      ui->buttonB,        ui->buttonX,        ui->buttonY,
        ui->buttonDpadUp, ui->buttonDpadDown, ui->buttonDpadLeft, ui->buttonDpadRight,
        ui->buttonL,      ui->buttonR,        ui->buttonStart,    ui->buttonSelect,
        ui->buttonDebug,  ui->buttonGpio14,   ui->buttonZL,       ui->buttonZR,
        ui->buttonHome,   ui->buttonPower,
    };

    button_names = {
        tr("A Button"),     tr("B Button"),      tr("X Button"),     tr("Y Button"),
        tr("D-Pad Up"),     tr("D-Pad Down"),    tr("D-Pad Left"),   tr("D-Pad Right"),
        tr("L Button"),     tr("R Button"),      tr("Start Button"), tr("Select Button"),
        tr("Debug"),        tr("GPIO4"),         tr("ZL Button"),    tr("ZR Button"),
        tr("Home Button"),  tr("Power Button")
    };
    // clang-format on

    /// A group of five QPushButtons represent one analog input. The buttons each represent up,
    /// down, left, right, and modifier, respectively.
    analog_map_buttons = {{
        {
            ui->buttonCircleUp,
            ui->buttonCircleDown,
            ui->buttonCircleLeft,
            ui->buttonCircleRight,
            ui->buttonCircleUpLeft,
            ui->buttonCircleUpRight,
            ui->buttonCircleDownLeft,
            ui->buttonCircleDownRight,
            nullptr,
        },
        {
            ui->buttonCStickUp,
            ui->buttonCStickDown,
            ui->buttonCStickLeft,
            ui->buttonCStickRight,
            ui->buttonCStickUpLeft,
            ui->buttonCStickUpRight,
            ui->buttonCStickDownLeft,
            ui->buttonCStickDownRight,
            nullptr,
        },
    }};

    analog_names = {tr("Circle Pad"), tr("C-Stick")};
    analog_map_stick = {ui->buttonCircleAnalog, ui->buttonCStickAnalog};
    analog_map_deadzone_and_modifier_slider = {ui->sliderCirclePadDeadzoneAndModifier,
                                               ui->sliderCStickDeadzoneAndModifier};
    analog_map_deadzone_and_modifier_slider_label = {ui->labelCirclePadDeadzoneAndModifier,
                                                     ui->labelCStickDeadzoneAndModifier};

    for (int button_id = 0; button_id < Settings::NativeButton::NumButtons; button_id++) {
        if (!button_map[button_id])
            continue;
        button_map[button_id]->setContextMenuPolicy(Qt::CustomContextMenu);
        connect(button_map[button_id], &QPushButton::clicked, [this, button_id]() {
            HandleClick(
                button_map[button_id],
                [this, button_id](Common::ParamPackage params) {
                    SetBinding({InputBindingType::NativeButton, QString(), button_id}, params);
                },
                InputCommon::Polling::DeviceType::Button);
        });
        connect(button_map[button_id], &QPushButton::customContextMenuRequested, this,
                [this, button_id](const QPoint& menu_location) {
                    QMenu context_menu;
                    context_menu.addAction(tr("Clear"), this, [&] {
                        ClearBinding({InputBindingType::NativeButton, QString(), button_id});
                    });
                    context_menu.addAction(tr("Restore Default"), this, [&] {
                        Common::ParamPackage default_mapping =
                            Common::ParamPackage{InputCommon::GenerateKeyboardParam(
                                QtConfig::default_buttons[button_id])};
                        SetBinding({InputBindingType::NativeButton, QString(), button_id},
                                   default_mapping);
                    });
                    context_menu.exec(button_map[button_id]->mapToGlobal(menu_location));
                });
    }

    for (int analog_id = 0; analog_id < Settings::NativeAnalog::NumAnalogs; analog_id++) {
        for (int sub_button_id = 0; sub_button_id < ANALOG_SUB_BUTTONS_NUM; sub_button_id++) {
            if (!analog_map_buttons[analog_id][sub_button_id])
                continue;
            analog_map_buttons[analog_id][sub_button_id]->setContextMenuPolicy(
                Qt::CustomContextMenu);
            connect(analog_map_buttons[analog_id][sub_button_id], &QPushButton::clicked, this,
                    [this, analog_id, sub_button_id]() {
                        HandleClick(
                            analog_map_buttons[analog_id][sub_button_id],
                            [this, analog_id, sub_button_id](const Common::ParamPackage& params) {
                                SetBinding({InputBindingType::AnalogFromButton, QString(),
                                            analog_id, sub_button_id},
                                           params);
                            },
                            InputCommon::Polling::DeviceType::Button);
                    });
            connect(analog_map_buttons[analog_id][sub_button_id],
                    &QPushButton::customContextMenuRequested, this,
                    [this, analog_id, sub_button_id](const QPoint& menu_location) {
                        QMenu context_menu;
                        context_menu.addAction(tr("Clear"), this, [&] {
                            ClearBinding({InputBindingType::AnalogFromButton, QString(), analog_id,
                                          sub_button_id});
                        });
                        context_menu.addAction(tr("Restore Default"), this, [&] {
                            Common::ParamPackage params{InputCommon::GenerateKeyboardParam(
                                QtConfig::default_analogs[analog_id][sub_button_id])};
                            SetBinding({InputBindingType::AnalogFromButton, QString(), analog_id,
                                        sub_button_id},
                                       params);
                        });
                        context_menu.exec(analog_map_buttons[analog_id][sub_button_id]->mapToGlobal(
                            menu_location));
                    });
        }
        connect(analog_map_stick[analog_id], &QPushButton::clicked, this, [this, analog_id]() {
            if (QMessageBox::information(
                    this, tr("Information"),
                    tr("After pressing OK, first move your joystick horizontally, "
                       "and then vertically."),
                    QMessageBox::Ok | QMessageBox::Cancel) == QMessageBox::Ok) {
                HandleClick(
                    analog_map_stick[analog_id],
                    [this, analog_id](const Common::ParamPackage& params) {
                        SetBinding({InputBindingType::NativeAnalog, QString(), analog_id}, params);
                    },
                    InputCommon::Polling::DeviceType::Analog);
            }
        });
        connect(analog_map_deadzone_and_modifier_slider[analog_id], &QSlider::valueChanged, this,
                [this, analog_id] {
                    const int slider_value =
                        analog_map_deadzone_and_modifier_slider[analog_id]->value();
                    const auto engine = analogs_param[analog_id].Get("engine", "");
                    if (engine == "sdl" || engine == "gcpad") {
                        analog_map_deadzone_and_modifier_slider_label[analog_id]->setText(
                            tr("Deadzone: %1%").arg(slider_value));
                        analogs_param[analog_id].Set("deadzone", slider_value / 100.0f);
                    } else {
                        analog_map_deadzone_and_modifier_slider_label[analog_id]->setText(
                            tr("Modifier Scale: %1%").arg(slider_value));
                        analogs_param[analog_id].Set("modifier_scale", slider_value / 100.0f);
                    }
                    ApplyConfiguration();
                });
    }

    // The Circle Mod button is common for both the sticks, so update the modifier settings
    // for both the sticks.
    connect(ui->buttonCircleMod, &QPushButton::clicked, this, [this]() {
        HandleClick(
            ui->buttonCircleMod,
            [this](const Common::ParamPackage& params) {
                SetBinding({InputBindingType::CModButton, QString()}, params);
            },
            InputCommon::Polling::DeviceType::Button);
    });
    ui->buttonCircleMod->setContextMenuPolicy(Qt::CustomContextMenu);
    connect(ui->buttonCircleMod, &QPushButton::customContextMenuRequested, this,
            [&](const QPoint& menu_location) {
                QMenu context_menu;
                context_menu.addAction(tr("Clear"), this, [&] {
                    ClearBinding({InputBindingType::CModButton, QString()});
                });

                context_menu.addAction(tr("Restore Default"), this, [&] {
                    Common::ParamPackage params{
                        InputCommon::GenerateKeyboardParam(QtConfig::default_analogs[0][4])};
                    SetBinding({InputBindingType::CModButton, QString()}, params);
                });
                context_menu.exec(ui->buttonCircleMod->mapToGlobal(menu_location));
            });

    connect(ui->buttonMotionTouch, &QPushButton::clicked, this, [this] {
        ui->buttonMotionTouch->setEnabled(false);
        QDialog* motion_touch_dialog = new ConfigureMotionTouch(this);
        motion_touch_dialog->exec();
        ui->buttonMotionTouch->setEnabled(true);
    });

    ui->buttonDelete->setEnabled(ui->profile->count() > 1);

    connect(ui->buttonAutoMap, &QPushButton::clicked, this, &ConfigureInput::AutoMap);
    connect(ui->buttonClearAll, &QPushButton::clicked, this, &ConfigureInput::ClearAll);
    connect(ui->buttonRestoreDefaults, &QPushButton::clicked, this,
            &ConfigureInput::RestoreDefaults);
    connect(ui->buttonNew, &QPushButton::clicked, this, &ConfigureInput::NewProfile);
    connect(ui->buttonDelete, &QPushButton::clicked, this, &ConfigureInput::DeleteProfile);
    connect(ui->buttonRename, &QPushButton::clicked, this, &ConfigureInput::RenameProfile);

    connect(ui->profile, qOverload<int>(&QComboBox::currentIndexChanged), this, [this](int i) {
        ApplyConfiguration();
        Settings::LoadProfile(i);
        LoadConfiguration();
    });

    timeout_timer->setSingleShot(true);
    connect(timeout_timer.get(), &QTimer::timeout, this, [this]() { SetPollingResult({}, true); });

    connect(poll_timer.get(), &QTimer::timeout, this, [this]() {
        Common::ParamPackage params;
        for (auto& poller : device_pollers) {
            params = poller->GetNextInput();
            // skip button downs and only process button ups to maintain former behavior
            if (params.Has("engine") && !params.Has("down")) {
                SetPollingResult(params, false);
                return;
            }
        }
    });

    LoadConfiguration();
}

ConfigureInput::~ConfigureInput() = default;

/**
 * Returns true if we find a conflict and should stop, otherwise it clears the map and returns true.
 */
bool ConfigureInput::CheckForDuplicateMap(const Common::ParamPackage& params,
                                          InputBinding this_binding) {
    auto const current_binding = GetMapping(params);
    bool abort = false;
    if (current_binding.binding_type != InputBindingType::Empty &&
        !(current_binding.binding_type == this_binding.binding_type &&
          current_binding.index == this_binding.index &&
          current_binding.sub_index == this_binding.sub_index)) {
        auto response =
            QMessageBox::information(this, tr("Key Already Bound"),
                                     tr("This key is already bound to the '%1' input.\n\n"
                                        "Continuing will unbind the previous input. Proceed?")
                                         .arg(current_binding.name),
                                     QMessageBox::Yes | QMessageBox::No, QMessageBox::Yes);
        if (response == QMessageBox::No) {
            abort = true;
        } else {
            ClearBinding(current_binding);
        }
    }
    return abort;
}

void ConfigureInput::SetBinding(InputBinding binding, const Common::ParamPackage& params) {
    bool abort = CheckForDuplicateMap(params, binding);
    if (!abort) {
        if (binding.binding_type == InputBindingType::NativeButton) {
            const auto button_id = binding.index;
            // Workaround for ZL & ZR for analog triggers like on XBOX controllors.
            // Analog triggers (from controllers like the XBOX controller) would not
            // work due to a different range of their signals (from 0 to 255 on
            // analog triggers instead of -32768 to 32768 on analog joysticks). The
            // SDL driver misinterprets analog triggers as analog joysticks.
            // TODO: reinterpret the signal range for analog triggers to map the
            // values correctly. This is required for the correct emulation of the
            // analog triggers of the GameCube controller.
            Common::ParamPackage new_params = params;
            if (button_id == Settings::NativeButton::ZL ||
                button_id == Settings::NativeButton::ZR) {
                new_params.Set("direction", "+");
                new_params.Set("threshold", "0.5");
            }
            buttons_param[button_id] = std::move(new_params);
        } else if (binding.binding_type == InputBindingType::AnalogFromButton) {
            const auto button_name = analog_sub_buttons[binding.sub_index];
            if (analogs_param[binding.index].Get("engine", "") != "analog_from_button") {
                analogs_param[binding.index] = {
                    {"engine", "analog_from_button"},
                };
            }
            analogs_param[binding.index].Set(button_name, params.Serialize());
        } else if (binding.binding_type == InputBindingType::NativeAnalog) {
            const auto analog_id = binding.index;
            analogs_param[analog_id] = params;
        } else if (binding.binding_type == InputBindingType::CModButton) {
            for (int analog_id = 0; analog_id < Settings::NativeAnalog::NumAnalogs; analog_id++) {
                if (analogs_param[analog_id].Get("engine", "") != "analog_from_button") {
                    analogs_param[analog_id] = {
                        {"engine", "analog_from_button"},
                    };
                }
                analogs_param[analog_id].Set("modifier", params.Serialize());
            }
        }
    }

    ApplyConfiguration();
    UpdateButtonLabels();
    Settings::SaveProfile(ui->profile->currentIndex());
}

void ConfigureInput::ApplyConfiguration() {

    Settings::values.use_artic_base_controller = ui->use_artic_controller->isChecked();
    UISettings::values.use_on_screen_software_keyboard = ui->use_onscreen_keyboard->isChecked();

    Settings::values.current_input_profile.maptype =
        static_cast<Settings::InputMappingType>(ui->comboBoxMappingType->currentIndex());

    std::transform(buttons_param.begin(), buttons_param.end(),
                   Settings::values.current_input_profile.buttons.begin(),
                   [](Common::ParamPackage& param) {
                       if (param.Get("engine", "keyboard") == "sdl") {
                           if (Settings::values.current_input_profile.maptype ==
                               Settings::InputMappingType::AllControllers)
                               param.Set("maptype", "all");
                           else if (Settings::values.current_input_profile.maptype ==
                                    Settings::InputMappingType::Guid)
                               param.Set("maptype", "guid");
                           else
                               param.Set("maptype", "guid+port");
                       } else {
                           param.Erase("maptype");
                       }
                       return param.Serialize();
                   });
    std::transform(analogs_param.begin(), analogs_param.end(),
                   Settings::values.current_input_profile.analogs.begin(),
                   [this](Common::ParamPackage& param) {
                       if (param.Get("engine", "keyboard") == "sdl") {
                           if (Settings::values.current_input_profile.maptype ==
                               Settings::InputMappingType::AllControllers) {
                               param.Set("maptype", "all");
                           } else if (Settings::values.current_input_profile.maptype ==
                                      Settings::InputMappingType::Guid) {
                               param.Set("maptype", "guid");
                           } else {
                               param.Set("maptype", "guid+port");
                           }
                       } else if (param.Get("engine", "keyboard") == "analog_from_button") {
                           for (int sub_button_id = 0; sub_button_id < ANALOG_SUB_BUTTONS_NUM - 1;
                                ++sub_button_id) {
                               auto dir = param.Get(analog_sub_buttons[sub_button_id], "");
                               if (dir != "") {
                                   auto dir_param = Common::ParamPackage(param.Get(dir, ""));
                                   if (Settings::values.current_input_profile.maptype ==
                                       Settings::InputMappingType::AllControllers) {
                                       dir_param.Set("maptype", "all");
                                   } else if (Settings::values.current_input_profile.maptype ==
                                              Settings::InputMappingType::Guid) {
                                       dir_param.Set("maptype", "guid");
                                   } else {
                                       dir_param.Set("maptype", "guid+port");
                                   }
                                   param.Set(dir, dir_param.Serialize());
                               }
                           }
                       } else {
                           param.Erase("maptype");
                       }
                       return param.Serialize();
                   });
    Settings::SaveProfile(Settings::values.current_input_profile_index);
}

void ConfigureInput::ApplyProfile() {
    Settings::values.current_input_profile_index = ui->profile->currentIndex();
}

void ConfigureInput::EmitInputKeysChanged() {
    emit InputKeysChanged(GetUsedKeyboardKeys());
}

void ConfigureInput::OnHotkeysChanged(
    QMap<QKeySequence, ConfigureInput::InputBinding> new_key_list) {
    hotkey_list = new_key_list;
}

void ConfigureInput::OnClearBinding(ConfigureInput::InputBinding binding) {
    ClearBinding(binding);
}

bool sameInput(const Common::ParamPackage& param1, const Common::ParamPackage& param2) {
    // if the engines or guid's don't match, return false as default
    if (!param1.Has("engine") || !param2.Has("engine"))
        return false;
    if (param1.Get("engine", "") != param2.Get("engine", ""))
        return false;
    if (param1.Get("guid", "") != param2.Get("guid", ""))
        return false;

    const bool sameCode = param1.Get("code", -1) == param2.Get("code", -2);
    const bool sameButton = param1.Get("button", -1) == param2.Get("button", -2);
    const bool sameAxisAndDirection = param1.Get("axis", -1) == param2.Get("axis", -2) &&
                                      param1.Get("direction", "a") == param2.Get("direction", "b");
    const bool sameAxisXAndAxisY = param1.Get("axis_x", -1) == param2.Get("axis_x", -2) &&
                                   param1.Get("axis_y", -1) == param2.Get("axis_y", -2);
    const bool sameHatAndDirection = param1.Get("hat", -1) == param2.Get("hat", -2) &&
                                     param1.Get("direction", "a") == param2.Get("direction", "b");
    return sameCode || sameButton || sameAxisAndDirection || sameAxisXAndAxisY ||
           sameHatAndDirection;
}

ConfigureInput::InputBinding ConfigureInput::GetMapping(const Common::ParamPackage& param) {
    if (!param.Has("engine"))
        return {InputBindingType::Empty, QString(), 0};
    // check for a button map
    for (int button = 0; button < Settings::NativeButton::NumButtons; ++button) {
        const auto& button_param = buttons_param[button];
        if (sameInput(param, button_param)) {
            return {InputBindingType::NativeButton, button_names[button], button};
        }
    }
    // check for an analog map
    for (int analog_id = 0; analog_id < Settings::NativeAnalog::NumAnalogs; ++analog_id) {
        const auto& analog_param = analogs_param[analog_id];
        if (analog_param.Get("engine", "") == "analog_from_button") {
            for (int sub_button_id = 0; sub_button_id < ANALOG_SUB_BUTTONS_NUM; ++sub_button_id) {
                const Common::ParamPackage sub_button{
                    analog_param.Get(analog_sub_buttons[sub_button_id], "")};
                if (sameInput(param, sub_button)) {
                    const auto input_ui_string = QStringLiteral("%1 (%2)").arg(
                        analog_names[analog_id], analog_sub_button_names[sub_button_id]);

                    if (analog_sub_buttons[sub_button_id] == "modifier") {
                        return {InputBindingType::CModButton, input_ui_string, 0};
                    }
                    return {InputBindingType::AnalogFromButton, input_ui_string, analog_id,
                            sub_button_id};
                }
            }
        } else if (sameInput(param, analog_param)) {
            return {InputBindingType::NativeAnalog, analog_names[analog_id], analog_id};
        }
    }

    if (param.Get("engine", "") == "keyboard" &&
        hotkey_list.contains(QKeySequence(param.Get("code", 0)))) {
        return hotkey_list[QKeySequence(param.Get("code", 0))];
    }

    return {InputBindingType::Empty, QStringLiteral(""), 0};
}

QMap<QKeySequence, ConfigureInput::InputBinding> ConfigureInput::GetUsedKeyboardKeys() {
    QMap<QKeySequence, ConfigureInput::InputBinding> list;
    for (int button = 0; button < Settings::NativeButton::NumButtons; button++) {
        const auto& button_param = buttons_param[button];
        if (button_param.Get("engine", "") == "keyboard") {
            list[QKeySequence(button_param.Get("code", 0))] = ConfigureInput::InputBinding{
                InputBindingType::NativeButton, button_names[button], button};
        }
    }

    for (int analog_id = 0; analog_id < Settings::NativeAnalog::NumAnalogs; ++analog_id) {
        const auto& analog_param = analogs_param[analog_id];
        if (analog_param.Get("engine", "") == "analog_from_button") {
            // stop one early so as not to include the "modifier" option
            for (int sub_button_id = 0; sub_button_id < ANALOG_SUB_BUTTONS_NUM - 1;
                 ++sub_button_id) {
                const Common::ParamPackage sub_button{
                    analog_param.Get(analog_sub_buttons[sub_button_id], "")};
                list[QKeySequence(sub_button.Get("code", 0))] = ConfigureInput::InputBinding{
                    InputBindingType::AnalogFromButton,
                    QStringLiteral("%1 (%2)").arg(analog_names[analog_id],
                                                  analog_sub_button_names[sub_button_id]),
                    analog_id, sub_button_id};
            }
            // add the circle mod button if it exist
            const Common::ParamPackage modButton{analog_param.Get("modifier", "")};
            if (modButton.Get("code", 0) != 0) {
                list[QKeySequence(modButton.Get("code", 0))] =
                    InputBinding{InputBindingType::CModButton, tr("Circle Mod")};
            }
        }
    }

    return list;
}

void ConfigureInput::LoadConfiguration() {
    ui->use_artic_controller->setChecked(Settings::values.use_artic_base_controller.GetValue());
    ui->comboBoxMappingType->setCurrentIndex(
        static_cast<int>(Settings::values.current_input_profile.maptype));
    ui->use_artic_controller->setEnabled(!system.IsPoweredOn());
    ui->use_onscreen_keyboard->setChecked(
        UISettings::values.use_on_screen_software_keyboard.GetValue());

    std::transform(Settings::values.current_input_profile.buttons.begin(),
                   Settings::values.current_input_profile.buttons.end(), buttons_param.begin(),
                   [](const std::string& str) { return Common::ParamPackage(str); });
    std::transform(Settings::values.current_input_profile.analogs.begin(),
                   Settings::values.current_input_profile.analogs.end(), analogs_param.begin(),
                   [](const std::string& str) { return Common::ParamPackage(str); });
    UpdateButtonLabels();
}

void ConfigureInput::RestoreDefaults() {
    for (int button_id = 0; button_id < Settings::NativeButton::NumButtons; button_id++) {
        buttons_param[button_id] = Common::ParamPackage{
            InputCommon::GenerateKeyboardParam(QtConfig::default_buttons[button_id])};
    }

    for (int analog_id = 0; analog_id < Settings::NativeAnalog::NumAnalogs; analog_id++) {
        analogs_param[analog_id] = Common::ParamPackage{InputCommon::GenerateAnalogParamFromKeys(
            QtConfig::default_analogs[analog_id][0], QtConfig::default_analogs[analog_id][1],
            QtConfig::default_analogs[analog_id][2], QtConfig::default_analogs[analog_id][3],
            QtConfig::default_analogs[analog_id][4], 0.5f)};
    }
    UpdateButtonLabels();

    ApplyConfiguration();
}

void ConfigureInput::ClearBinding(InputBinding binding) {
    if (binding.binding_type == InputBindingType::NativeButton) {
        buttons_param[binding.index].Clear();
        button_map[binding.index]->setText(tr("[not set]"));
    } else if (binding.binding_type == InputBindingType::AnalogFromButton) {
        const auto analog_id = binding.index;
        const auto sub_button_id = binding.sub_index;
        analogs_param[analog_id].Erase(analog_sub_buttons[sub_button_id]);
        analog_map_buttons[analog_id][sub_button_id]->setText(tr("[not set]"));
    } else if (binding.binding_type == InputBindingType::NativeAnalog) {
        const auto analog_id = binding.index;
        analogs_param[analog_id].Clear();
        UpdateButtonLabels();
    } else if (binding.binding_type == InputBindingType::Hotkey) {
        emit ClearHotkey(binding);
    } else if (binding.binding_type == InputBindingType::CModButton) {
        for (int analog_id = 0; analog_id < Settings::NativeAnalog::NumAnalogs; analog_id++) {
            analogs_param[analog_id].Erase("modifier");
        }
        ui->buttonCircleMod->setText(tr("[not set]"));
    }
    ApplyConfiguration();
}

void ConfigureInput::ClearAll() {
    for (int button_id = 0; button_id < Settings::NativeButton::NumButtons; button_id++) {
        if (button_map[button_id] && button_map[button_id]->isEnabled())
            buttons_param[button_id].Clear();
    }
    for (int analog_id = 0; analog_id < Settings::NativeAnalog::NumAnalogs; analog_id++) {
        analogs_param[analog_id].Clear();
    }
    UpdateButtonLabels();

    ApplyConfiguration();
}

void ConfigureInput::UpdateButtonLabels() {
    for (int button = 0; button < Settings::NativeButton::NumButtons; button++) {
        if (button_map[button])
            button_map[button]->setText(ButtonToText(buttons_param[button]));
    }

    for (int analog_id = 0; analog_id < Settings::NativeAnalog::NumAnalogs; analog_id++) {
        for (int sub_button_id = 0; sub_button_id < ANALOG_SUB_BUTTONS_NUM; sub_button_id++) {
            if (analog_map_buttons[analog_id][sub_button_id]) {
                analog_map_buttons[analog_id][sub_button_id]->setText(
                    AnalogToText(analogs_param[analog_id], analog_sub_buttons[sub_button_id]));
            }
        }
        analog_map_stick[analog_id]->setText(tr("Set Analog Stick"));

        auto& param = analogs_param[analog_id];
        auto* const analog_stick_slider = analog_map_deadzone_and_modifier_slider[analog_id];
        auto* const analog_stick_slider_label =
            analog_map_deadzone_and_modifier_slider_label[analog_id];

        if (param.Has("engine")) {
            const auto engine{param.Get("engine", "")};
            if (engine == "sdl" || engine == "gcpad") {
                if (!param.Has("deadzone")) {
                    param.Set("deadzone", 0.1f);
                }
                const auto slider_value = static_cast<int>(param.Get("deadzone", 0.1f) * 100);
                analog_stick_slider_label->setText(tr("Deadzone: %1%").arg(slider_value));
                analog_stick_slider->setValue(slider_value);
            } else {
                if (!param.Has("modifier_scale")) {
                    param.Set("modifier_scale", 0.5f);
                }
                const auto slider_value = static_cast<int>(param.Get("modifier_scale", 0.5f) * 100);
                analog_stick_slider_label->setText(tr("Modifier Scale: %1%").arg(slider_value));
                analog_stick_slider->setValue(slider_value);
            }
        }
    }

    ui->buttonCircleMod->setText(AnalogToText(analogs_param[0], "modifier"));

    EmitInputKeysChanged();
}

void ConfigureInput::MapFromButton(const Common::ParamPackage& params) {
    Common::ParamPackage aux_param;
    bool mapped = false;
    for (int button_id = 0; button_id < Settings::NativeButton::NumButtons; button_id++) {
        aux_param = InputCommon::GetControllerButtonBinds(params, button_id);
        if (aux_param.Has("engine")) {
            buttons_param[button_id] = aux_param;
            mapped = true;
        }
    }
    for (int analog_id = 0; analog_id < Settings::NativeAnalog::NumAnalogs; analog_id++) {
        aux_param = InputCommon::GetControllerAnalogBinds(params, analog_id);
        if (aux_param.Has("engine")) {
            analogs_param[analog_id] = aux_param;
            mapped = true;
        }
    }
    if (!mapped) {
        QMessageBox::warning(
            this, tr("Warning"),
            tr("Auto mapping failed. Your controller may not have a corresponding mapping"));
    }
}

void ConfigureInput::AutoMap() {
    ui->buttonAutoMap->setEnabled(false);
    QMessageBox box(this);
    box.setWindowTitle(tr("Auto map Controller"));
    box.setText(tr("After pressing OK, press the A (right) button on your gamepad"));
    box.setStandardButtons(QMessageBox::Ok | QMessageBox::Cancel);
    QPixmap pixmap(QStringLiteral(":/icons/default/256x256/automap_face_buttons.png"));
    pixmap = pixmap.scaled(64, 64, Qt::KeepAspectRatio, Qt::SmoothTransformation);
    box.setIconPixmap(pixmap);
    int result = box.exec();
    if (result == QMessageBox::Cancel) {
        ui->buttonAutoMap->setEnabled(true);
        return;
    }
    input_setter = [this](const Common::ParamPackage& params) {
        MapFromButton(params);
        ApplyConfiguration();
    };
    device_pollers = InputCommon::Polling::GetPollers(InputCommon::Polling::DeviceType::Button);
    want_keyboard_keys = false;
    for (auto& poller : device_pollers) {
        poller->Start();
    }
    timeout_timer->start(5000); // Cancel after 5 seconds
    poll_timer->start(200);     // Check for new inputs every 200ms
    ui->buttonAutoMap->setEnabled(true);
}

void ConfigureInput::HandleClick(QPushButton* button,
                                 std::function<void(const Common::ParamPackage&)> new_input_setter,
                                 InputCommon::Polling::DeviceType type) {
    previous_key_code = QKeySequence(button->text())[0].toCombined();
    button->setText(tr("[press key]"));
    button->setFocus();

    input_setter = new_input_setter;

    device_pollers = InputCommon::Polling::GetPollers(type);

    // Keyboard keys can only be used as button devices
    want_keyboard_keys = type == InputCommon::Polling::DeviceType::Button;

    for (auto& poller : device_pollers) {
        poller->Start();
    }

    grabKeyboard();
    grabMouse();
    timeout_timer->start(5000); // Cancel after 5 seconds
    poll_timer->start(200);     // Check for new inputs every 200ms
}

void ConfigureInput::StopPolling() {
    releaseKeyboard();
    releaseMouse();
    timeout_timer->stop();
    poll_timer->stop();
    for (auto& poller : device_pollers) {
        poller->Stop();
    }
}

void ConfigureInput::SetPollingResult(const Common::ParamPackage& params, bool abort) {
    StopPolling();
    if (!abort && input_setter) {
        (*input_setter)(params);
    }
    UpdateButtonLabels();
    input_setter.reset();
}

void ConfigureInput::keyPressEvent(QKeyEvent* event) {
    if (!input_setter || !event)
        return;

    if (event->key() != Qt::Key_Escape && event->key() != previous_key_code) {
        if (want_keyboard_keys) {
            auto param = Common::ParamPackage(InputCommon::GenerateKeyboardParam(event->key()));
            previous_key_code = 0;
            SetPollingResult(param, false);
        } else {
            // Escape key wasn't pressed and we don't want any keyboard keys, so don't
            // stop polling
            return;
        }
    }
    SetPollingResult({}, true);
    previous_key_code = 0;
}

void ConfigureInput::RetranslateUI() {
    ui->retranslateUi(this);
}

void ConfigureInput::NewProfile() {
    ui->buttonNew->setEnabled(false);
    const QString name =
        QInputDialog::getText(this, tr("New Profile"), tr("Enter the name for the new profile."));
    if (name.isEmpty()) {
        ui->buttonNew->setEnabled(true);
        return;
    }
    if (IsProfileNameDuplicate(name)) {
        WarnProposedProfileNameIsDuplicate();
        ui->buttonNew->setEnabled(true);
        return;
    }

    ApplyConfiguration();
    Settings::CreateProfile(name.toStdString());
    ui->profile->addItem(name);
    ui->profile->setCurrentIndex(Settings::values.current_input_profile_index);
    LoadConfiguration();
    ui->buttonDelete->setEnabled(ui->profile->count() > 1);
    ui->buttonNew->setEnabled(true);
}

void ConfigureInput::DeleteProfile() {
    ui->buttonDelete->setEnabled(false);
    const auto answer = QMessageBox::question(
        this, tr("Delete Profile"), tr("Delete profile %1?").arg(ui->profile->currentText()));
    if (answer != QMessageBox::Yes) {
        ui->buttonDelete->setEnabled(true);
        return;
    }
    const int index = ui->profile->currentIndex();
    ui->profile->removeItem(index);
    ui->profile->setCurrentIndex(0);
    Settings::DeleteProfile(index);
    LoadConfiguration();
    ui->buttonDelete->setEnabled(ui->profile->count() > 1);
}

void ConfigureInput::RenameProfile() {
    ui->buttonRename->setEnabled(false);
    const QString new_name = QInputDialog::getText(this, tr("Rename Profile"), tr("New name:"));
    if (new_name.isEmpty()) {
        ui->buttonRename->setEnabled(true);
        return;
    }
    if (IsProfileNameDuplicate(new_name)) {
        WarnProposedProfileNameIsDuplicate();
        ui->buttonRename->setEnabled(true);
        return;
    }

    ui->profile->setItemText(ui->profile->currentIndex(), new_name);
    Settings::RenameCurrentProfile(new_name.toStdString());
    Settings::SaveProfile(ui->profile->currentIndex());
    ui->buttonRename->setEnabled(true);
}

bool ConfigureInput::IsProfileNameDuplicate(const QString& name) const {
    return ui->profile->findText(name, Qt::MatchFixedString | Qt::MatchCaseSensitive) != -1;
}

void ConfigureInput::WarnProposedProfileNameIsDuplicate() {
    QMessageBox::warning(this, tr("Duplicate profile name"),
                         tr("Profile name already exists. Please choose a different name."));
}
