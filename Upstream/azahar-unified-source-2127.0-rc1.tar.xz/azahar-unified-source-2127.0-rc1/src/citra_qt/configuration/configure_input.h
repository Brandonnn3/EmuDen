// Copyright 2017-2026 Citra Emulator Project / Azahar Emulator Project
// Licensed under GPLv2 or any later version
// Refer to the misc/licenses/gplv2.txt file included.

#pragma once

#include <array>
#include <functional>
#include <memory>
#include <optional>
#include <string>
#include <QKeySequence>
#include <QWidget>
#include "common/param_package.h"
#include "common/settings.h"
#include "input_common/main.h"

class QKeyEvent;
class QLabel;
class QPushButton;
class QSlider;
class QString;
class QTimer;

namespace Ui {
class ConfigureInput;
}

class ConfigureInput : public QWidget {
    Q_OBJECT

public:
    enum class InputBindingType {
        NativeButton,
        AnalogFromButton,
        NativeAnalog,
        Hotkey,
        CModButton,
        Empty
    };
    struct InputBinding {
        ConfigureInput::InputBindingType binding_type;
        QString name;
        int index = -1;     // used for anything there are multiple of
        int sub_index = -1; // used for sub-buttons
    };

    explicit ConfigureInput(Core::System& system, QWidget* parent = nullptr);
    ~ConfigureInput() override;

    /// Save all button configurations to settings file
    void ApplyConfiguration();
    void RetranslateUI();

    /// Load configuration settings.
    void LoadConfiguration();
    void EmitInputKeysChanged();

    /// Save the current input profile index
    void ApplyProfile();

public slots:
    void OnHotkeysChanged(QMap<QKeySequence, ConfigureInput::InputBinding> new_key_list);
    void OnClearBinding(ConfigureInput::InputBinding binding);

signals:
    void InputKeysChanged(QMap<QKeySequence, ConfigureInput::InputBinding> new_key_list);
    void ClearHotkey(ConfigureInput::InputBinding hotkey_to_clear);

private:
    Core::System& system;
    std::unique_ptr<Ui::ConfigureInput> ui;

    std::unique_ptr<QTimer> timeout_timer;
    std::unique_ptr<QTimer> poll_timer;

    /// This will be the the setting function when an input is awaiting configuration.
    std::optional<std::function<void(const Common::ParamPackage&)>> input_setter;

    std::array<Common::ParamPackage, Settings::NativeButton::NumButtons> buttons_param;
    std::array<Common::ParamPackage, Settings::NativeAnalog::NumAnalogs> analogs_param;

    static constexpr int ANALOG_SUB_BUTTONS_NUM = 9;

    /// Each button input is represented by a QPushButton.
    std::array<QPushButton*, Settings::NativeButton::NumButtons> button_map;
    std::array<QString, Settings::NativeButton::NumButtons> button_names;
    std::array<QString, Settings::NativeAnalog::NumAnalogs> analog_names;

    /// A group of five QPushButtons represent one analog input. The buttons each represent up,
    /// down, left, right, and modifier, respectively.
    std::array<std::array<QPushButton*, ANALOG_SUB_BUTTONS_NUM>, Settings::NativeAnalog::NumAnalogs>
        analog_map_buttons;

    /// Analog inputs are also represented each with a single button, used to configure with an
    /// actual analog stick
    std::array<QPushButton*, Settings::NativeAnalog::NumAnalogs> analog_map_stick;
    std::array<QSlider*, Settings::NativeAnalog::NumAnalogs>
        analog_map_deadzone_and_modifier_slider;
    std::array<QLabel*, Settings::NativeAnalog::NumAnalogs>
        analog_map_deadzone_and_modifier_slider_label;

    std::array<std::string, ANALOG_SUB_BUTTONS_NUM> analog_sub_buttons;
    std::array<QString, ANALOG_SUB_BUTTONS_NUM> analog_sub_button_names;

    std::vector<std::unique_ptr<InputCommon::Polling::DevicePoller>> device_pollers;

    /**
     * List of keys currently registered to hotkeys.
     * These can't be bound to any input key.
     * Synchronised with ConfigureHotkeys via signal-slot.
     */
    QMap<QKeySequence, ConfigureInput::InputBinding> hotkey_list;

    /// A flag to indicate if keyboard keys are okay when configuring an input. If this is false,
    /// keyboard events are ignored.
    bool want_keyboard_keys = false;

    /// Generates list of all used keyboard keys for sharing with hotkey code
    QMap<QKeySequence, ConfigureInput::InputBinding> GetUsedKeyboardKeys();
    InputBinding GetMapping(const Common::ParamPackage& param);

    void ClearBinding(InputBinding binding);
    void SetBinding(InputBinding binding, const Common::ParamPackage& params);
    bool CheckForDuplicateMap(const Common::ParamPackage& params, InputBinding this_binding);
    void MapFromButton(const Common::ParamPackage& params);
    void AutoMap();

    /// Restore all buttons to their default values.
    void RestoreDefaults();
    /// Clear all input configuration
    void ClearAll();

    /// Update UI to reflect current configuration.
    void UpdateButtonLabels();

    /// Called when the button was pressed.
    void HandleClick(QPushButton* button,
                     std::function<void(const Common::ParamPackage&)> new_input_setter,
                     InputCommon::Polling::DeviceType type);

    /// The key code of the previous state of the key being currently bound.
    int previous_key_code;

    /// Stop polling
    void StopPolling();
    /// configure input using the input_setter
    void SetPollingResult(const Common::ParamPackage& params, bool abort);

    /// Handle key press events.
    void keyPressEvent(QKeyEvent* event) override;

    /// input profiles
    void NewProfile();
    void DeleteProfile();
    void RenameProfile();

    bool IsProfileNameDuplicate(const QString& name) const;
    void WarnProposedProfileNameIsDuplicate();
};
