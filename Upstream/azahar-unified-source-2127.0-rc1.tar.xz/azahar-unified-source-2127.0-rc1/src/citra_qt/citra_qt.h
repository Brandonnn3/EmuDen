// Copyright 2014-2026 Citra Emulator Project / Azahar Emulator Project
// Licensed under GPLv3 or any later version
// Refer to the LICENSE.txt file included.

#pragma once

#include <array>
#include <memory>
#include <set>
#include <vector>
#ifdef __unix__
#include <QDBusObjectPath>
#endif
#ifdef ENABLE_QT_UPDATE_CHECKER
#include <QFuture>
#include <QFutureWatcher>
#endif
#include <QMainWindow>
#include <QPushButton>
#include <QString>
#include <QTimer>
#include <QTranslator>
#include "citra_qt/compatibility_list.h"
#include "citra_qt/hotkeys.h"
#include "citra_qt/notification_led.h"
#include "citra_qt/user_data_migration.h"
#include "core/core.h"
#include "core/savestate.h"
#include "video_core/rasterizer_interface.h"

// Needs to be included at the end due to https://bugreports.qt.io/browse/QTBUG-73263
#include <filesystem>

class AboutDialog;
class QtConfig;
class ClickableLabel;
class EmuThread;
class GameList;
enum class GameListOpenTarget;
class GameListPlaceholder;
enum class GameListShortcutTarget;
class GImageInfo;
class GPUCommandListWidget;
class GPUCommandStreamWidget;
class GraphicsBreakPointsWidget;
class GraphicsTracingWidget;
class GraphicsVertexShaderWidget;
class GRenderWindow;
class IPCRecorderWidget;
class LLEServiceModulesWidget;
class LoadingScreen;
#if MICROPROFILE_ENABLED
class MicroProfileDialog;
#endif
class MultiplayerState;
class ProfilerWidget;
class QFileOpenEvent;
template <typename>
class QFutureWatcher;
class QLabel;
class QProgressBar;
class QPushButton;
class QSlider;
class RegistersWidget;
class WaitTreeWidget;

namespace Camera {
class QtMultimediaCameraHandlerFactory;
}

#ifdef ENABLE_DISCORD_RPC
namespace DiscordRPC {
class DiscordInterface;
}
#endif

namespace PlayTime {
class PlayTimeManager;
}

namespace Core {
class Movie;
}

namespace Ui {
class MainWindow;
}

namespace Service::AM {
enum class InstallStatus : u32;
}

namespace Service::FS {
enum class MediaType : u32;
}

int LaunchQtFrontend(int argc, char* argv[]);

class GApplicationEventFilter : public QObject {
    Q_OBJECT

public:
    /** Holds a pointer to the hotkey registry so we can catch held hotkeys */
    HotkeyRegistry* hotkey_registry = nullptr;

signals:
    void FileOpen(const QFileOpenEvent* event);
    void SequencePressCaught(QKeySequence seq);
    void SequenceReleaseCaught(QKeySequence seq);

protected:
    bool eventFilter(QObject* object, QEvent* event) override;

private:
    std::set<Hotkey*> hotkeys_currently_held{};
};

class GMainWindow : public QMainWindow {
    Q_OBJECT

    /// Max number of recently loaded items to keep track of
    static const int max_recent_files_item = 10;

public:
    void filterBarSetChecked(bool state);
#ifdef _WIN32
    void SetCustomWindowsScrollbar();
#endif
    void UpdateUITheme();

    explicit GMainWindow(Core::System& system);
    ~GMainWindow();

    GameList* game_list;
    std::unique_ptr<PlayTime::PlayTimeManager> play_time_manager;
#ifdef ENABLE_DISCORD_RPC
    std::unique_ptr<DiscordRPC::DiscordInterface> discord_rpc;
#endif

    bool DropAction(QDropEvent* event);
    void AcceptDropEvent(QDropEvent* event);

    void OnFileOpen(const QFileOpenEvent* event);
    void OnSequencePressed(QKeySequence seq);
    void OnSequenceReleased(QKeySequence seq);
    void UninstallTitles(
        const std::vector<std::tuple<Service::FS::MediaType, u64, QString>>& titles);

public slots:
    void OnAppFocusStateChanged(Qt::ApplicationState state);
    void OnLoadComplete();

signals:

    /**
     * Signal that is emitted when a new EmuThread has been created and an emulation session is
     * about to start. At this time, the core system emulation has been initialized, and all
     * emulation handles and memory should be valid.
     *
     * @param emu_thread Pointer to the newly created EmuThread (to be used by widgets that need
     * to access/change emulation state).
     */
    void EmulationStarting(EmuThread* emu_thread);

    /**
     * Signal that is emitted when emulation is about to stop. At this time, the EmuThread and core
     * system emulation handles and memory are still valid, but are about become invalid.
     */
    void EmulationStopping();

    void UpdateProgress(std::size_t written, std::size_t total);
    void CIAInstallReport(Service::AM::InstallStatus status, QString filepath);
    void CompressFinished(bool is_compress, bool success);
    void BundleFinished(bool is_bundle, bool success);
    void CIAInstallFinished();
    void InfoLEDColorChanged();
    // Signal that tells widgets to update icons to use the current theme
    void UpdateThemedIcons();
    void InstalledTitlesChanged();

private:
    void InitializeWidgets();
    void InitializeDebugWidgets();
    void InitializeRecentFileMenuActions();
    void InitializeSaveStateMenuActions();

    void SetDefaultUIGeometry();
    void SyncMenuUISettings();
    void RestoreUIState();

    void ConnectAppEvents();
    void ConnectWidgetEvents();
    void ConnectMenuEvents();
    void UpdateMenuState();

    void PreventOSSleep();
    void AllowOSSleep();

    bool LoadROM(const QString& filename);
    void BootGame(const QString& filename);
    void ShutdownGame();

#ifdef ENABLE_DISCORD_RPC
    void SetDiscordEnabled(bool state);
#endif
    void LoadAmiibo(const QString& filename);

    /**
     * Stores the filename in the recently loaded files list.
     * The new filename is stored at the beginning of the recently loaded files list.
     * After inserting the new entry, duplicates are removed meaning that if
     * this was inserted from \a OnMenuRecentFile(), the entry will be put on top
     * and remove from its previous position.
     *
     * Finally, this function calls \a UpdateRecentFiles() to update the UI.
     *
     * @param filename the filename to store
     */
    void StoreRecentFile(const QString& filename);

    /**
     * Updates the recent files menu.
     * Menu entries are rebuilt from the configuration file.
     * If there is no entry in the menu, the menu is greyed out.
     */
    void UpdateRecentFiles();

    void UpdateSaveStates();

    /**
     * If the emulation is running,
     * asks the user if he really want to close the emulator
     *
     * @return true if the user confirmed
     */
    bool ConfirmClose();
    bool ConfirmChangeGame();
    void closeEvent(QCloseEvent* event) override;

    enum {
        CREATE_SHORTCUT_MSGBOX_FULLSCREEN_PROMPT,
        CREATE_SHORTCUT_MSGBOX_SUCCESS,
        CREATE_SHORTCUT_MSGBOX_ERROR,
        CREATE_SHORTCUT_MSGBOX_APPIMAGE_VOLATILE_WARNING,
    };

    bool CreateShortcutMessagesGUI(QWidget* parent, int message, const QString& game_title);
    bool MakeShortcutIcoPath(const u64 program_id, const std::string_view game_file_name,
                             std::filesystem::path& out_icon_path);
    bool CreateShortcutLink(const std::filesystem::path& shortcut_path, const std::string& comment,
                            const std::filesystem::path& icon_path, const std::string& command,
                            const std::string& arguments, const std::string& categories,
                            const std::string& keywords, const std::string& name,
                            const bool& skip_tryexec);

    void ShowCommandOutput(std::string title, std::string message);

private slots:
    void OnResumeGame(bool first_start);
    void OnRestartGame();
    void OnPauseGame();
    void OnPauseContinueGame();
    void OnStopGame();
    void OnSaveState();
    void OnLoadState();
    /// Called whenever a user selects a game in the game list widget.
    void OnGameListLoadFile(QString game_path);
    void OnGameListOpenFolder(u64 program_id, GameListOpenTarget target);
    void OnGameListRemovePlayTimeData(u64 program_id);
    void OnGameListCreateShortcut(u64 program_id, const std::string& game_path,
                                  GameListShortcutTarget target);
    void OnGameListDumpRomFS(QString game_path, u64 program_id);
    void OnGameListOpenDirectory(const QString& directory);
    void OnGameListAddDirectory();
    void OnGameListShowList(bool show);
    void OnGameListOpenPerGameProperties(const QString& file);
    void OnConfigurePerGame();
    void OnMenuLoadFile();
    void OnMenuSetUpSystemFiles();
    void OnMenuInstallCIA();
    void OnMenuConnectArticBase();
    void OnMenuBootHomeMenu(u32 region);
    void OnUpdateProgress(std::size_t written, std::size_t total);
    void OnCIAInstallReport(Service::AM::InstallStatus status, QString filepath);
    void OnCompressFinished(bool is_compress, bool success);
    void OnBundleFinished(bool is_bundle, bool success);
    void OnCIAInstallFinished();
    void OnMenuRecentFile();
    void OnConfigure();
    void OnLoadAmiibo();
    void OnRemoveAmiibo();
    void OnOpenCitraFolder();
    void OnOpenNANDFolder();
    void OnOpenSDMCFolder();
    void OnToggleFilterBar();
    void OnDisplayTitleBars(bool);
    void InitializeHotkeys();
    void ToggleFullscreen();
    void ToggleSecondaryFullscreen();
    void ChangeScreenLayout();
    void ChangeSmallScreenPosition();
    bool IsTurboEnabled();
    void SetTurboEnabled(bool);
    void ReloadTurbo();
    void AdjustSpeedLimit(bool increase);
    void UpdateSecondaryWindowVisibility();
    void ToggleScreenLayout();
    void OnSwapScreens();
    void OnRotateScreens();
    void TriggerSwapScreens();
    void TriggerRotateScreens();
    void ShowFullscreen();
    void HideFullscreen();
    void ToggleWindowMode();
    void OnCreateGraphicsSurfaceViewer();
    void OnRecordMovie();
    void OnPlayMovie();
    void OnCloseMovie();
    void OnSaveMovie();
    void OnCaptureScreenshot();
    void OnCompressFile();
    void OnDecompressFile();
    void OnCreateBundle();
    void OnExtractBundle();
#ifdef ENABLE_FFMPEG
    void OnDumpVideo();
    void OnStartVideoDumping();
    void StartVideoDumping(const QString& path);
    void OnStopVideoDumping();
#endif
    void OnCoreError(Core::System::ResultStatus, std::string);
    bool ShowExceptionDialog(Core::System::ResultStatus result, const std::string& details);
    /// Called whenever a user selects Help->About Azahar
    void OnMenuAboutCitra();

    void OnLanguageChanged(const QString& locale);
    void OnMouseActivity();

    void OnDecreaseVolume();
    void OnIncreaseVolume();
    void OnMute();
#ifdef ENABLE_QT_UPDATE_CHECKER
    void OnEmulatorUpdateAvailable();
#endif
    void OnSwitchDiskResources(VideoCore::LoadCallbackStage stage, std::size_t value,
                               std::size_t total, const std::string& object);
#ifdef ENABLE_DEVELOPER_OPTIONS
    void StartLaunchStressTest(const QString& game_path);
#endif

private:
    Q_INVOKABLE void OnMoviePlaybackCompleted();
    void UpdateStatusBar();
    void UpdateBootHomeMenuState();
    void LoadTranslation();
    void UpdateWindowTitle();
    void UpdateUISettings();
    void RetranslateStatusBar();
    void RemovePlayTimeData(u64 program_id);
    void InstallCIA(QStringList filepaths);
    void HideMouseCursor();
    void ShowMouseCursor();
    void OpenPerGameConfiguration(u64 title_id, const QString& file_name);
    void UpdateVolumeUI();
    void UpdateAPIIndicator(bool update = false);
    void UpdateStatusButtons();
#ifdef __unix__
    void SetGamemodeEnabled(bool state);
#endif

    std::unique_ptr<Ui::MainWindow> ui;
    Core::System& system;
    Core::Movie& movie;
    GApplicationEventFilter* filter = new GApplicationEventFilter();
    GRenderWindow* render_window;
    GRenderWindow* secondary_window;

    GameListPlaceholder* game_list_placeholder;
    LoadingScreen* loading_screen;

    // Status bar elements
    QProgressBar* progress_bar = nullptr;
    QLabel* message_label = nullptr;
    bool show_artic_label = false;
    QLabel* loading_shaders_label = nullptr;
    QLabel* artic_traffic_label = nullptr;
    QLabel* emu_speed_label = nullptr;
    QLabel* game_fps_label = nullptr;
    QLabel* emu_frametime_label = nullptr;
    QPushButton* graphics_api_button = nullptr;
    QPushButton* volume_button = nullptr;
    QWidget* volume_popup = nullptr;
    QSlider* volume_slider = nullptr;
    QTimer status_bar_update_timer;
    bool message_label_used_for_movie = false;

    MultiplayerState* multiplayer_state = nullptr;

    LedWidget* notification_led = nullptr;

    // Created before `config` to ensure that emu data directory
    // isn't created before the check is performed
    UserDataMigrator user_data_migrator;
    std::unique_ptr<QtConfig> config;

    // Hotkeys
    bool turbo_mode_active = false;

    // Whether emulation is currently running in Citra.
    bool emulation_running = false;
    std::unique_ptr<EmuThread> emu_thread;
    // The title of the game currently running
    QString game_title;
    // The path to the game currently running
    QString game_path;
    // The title id of the game currently running
    u64 game_title_id;

    bool auto_paused = false;
    bool auto_muted = false;
    QTimer mouse_hide_timer;

    // Movie
    bool movie_record_on_start = false;
    QString movie_record_path;
    QString movie_record_author;

    bool movie_playback_on_start = false;
    QString movie_playback_path;

    // Video dumping
    bool video_dumping_on_start = false;
    QString video_dumping_path;
    // Whether game shutdown is delayed due to video dumping
    bool game_shutdown_delayed = false;
    // Whether game was paused due to stopping video dumping
    bool game_paused_for_dumping = false;

    int gdbport_from_arg = -1;

    QString gl_renderer;
    std::vector<QString> physical_devices;

    // Debugger panes
    ProfilerWidget* profilerWidget{};
#if MICROPROFILE_ENABLED
    MicroProfileDialog* microProfileDialog{};
#endif
    RegistersWidget* registersWidget{};
    GPUCommandStreamWidget* graphicsWidget{};
    GPUCommandListWidget* graphicsCommandsWidget{};
    GraphicsBreakPointsWidget* graphicsBreakpointsWidget{};
    GraphicsVertexShaderWidget* graphicsVertexShaderWidget{};
    GraphicsTracingWidget* graphicsTracingWidget{};
    IPCRecorderWidget* ipcRecorderWidget{};
    LLEServiceModulesWidget* lleServiceModulesWidget{};
    WaitTreeWidget* waitTreeWidget{};

    QAction* actions_recent_files[max_recent_files_item];
    std::array<QAction*, Core::SaveStateSlotCount> actions_load_state;
    std::array<QAction*, Core::SaveStateSlotCount> actions_save_state;

    u32 oldest_slot;
    u64 oldest_slot_time;
    u32 newest_slot;
    u64 newest_slot_time;

    // Secondary window actions
    QAction* action_secondary_fullscreen;
    QAction* action_secondary_toggle_screen;
    QAction* action_secondary_swap_screen;
    QAction* action_secondary_rotate_screen;

    QTranslator qtTranslator;
    QTranslator citraTranslator;

    // stores default icon theme search paths for the platform
    QStringList default_theme_paths;

    HotkeyRegistry hotkey_registry;

    std::shared_ptr<Camera::QtMultimediaCameraHandlerFactory> qt_cameras;

#ifdef ENABLE_QT_UPDATE_CHECKER
    // Prompt shown when update check succeeds
    QFuture<QString> update_future;
    QFutureWatcher<QString> update_watcher;
#endif

#ifdef __unix__
    QDBusObjectPath wake_lock{};
#endif

protected:
    void dropEvent(QDropEvent* event) override;
    void dragEnterEvent(QDragEnterEvent* event) override;
    void dragMoveEvent(QDragMoveEvent* event) override;
    void mouseMoveEvent(QMouseEvent* event) override;
    void mousePressEvent(QMouseEvent* event) override;
    void mouseReleaseEvent(QMouseEvent* event) override;
    void showEvent(QShowEvent* event) override;
};

Q_DECLARE_METATYPE(std::size_t);
Q_DECLARE_METATYPE(Service::AM::InstallStatus);
